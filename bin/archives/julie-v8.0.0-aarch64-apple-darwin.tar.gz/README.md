# julie-semantic-sidecar

A thin Rust stdio binary that turns text into embedding vectors. It speaks the frozen
`julie.embedding.sidecar` v1 protocol — newline-delimited JSON on stdin/stdout, methods
`health`, `embed_query`, `embed_batch`, `shutdown` — and embeds via a pinned llama.cpp with
Metal / Vulkan / CPU backends. Consumers (Miller, Julie) spawn it and talk NDJSON; they never
download models or compute model paths.

**Release line: `v0.1.0` stable.**
See the local [release notes](docs/release-notes/v0.1.0.md) for the change summary and evidence
boundary. RC5 source, reproducibility, and hardware results informed this release, but versioning
changes the executable and archive bytes. Stable support claims are bound to the exact archive
checksums that pass the applicable physical-hardware gates. CUDA is not included in `v0.1.0`.

## Launch interface

```
julie-semantic-sidecar [serve [--model <id>]]   # default verb; default model bge-small-en-v1.5-f32
julie-semantic-sidecar prepare [--model <id>]   # download + verify a model into the shared cache
julie-semantic-sidecar broker --model <id> --endpoint <path> --lock <path> --accelerator-lock <path>
julie-semantic-sidecar --version
```

`serve` reads requests from stdin and writes one response line per request to stdout until EOF.
`broker` serves the same frozen protocol over a current-user local endpoint. The process keeps the
model-service and any acquired accelerator lock for its lifetime, accepts multiple connections, and
exits when its inherited owner stdin reaches EOF. The lock holder alone removes a stale Unix socket;
the broker directory and socket are restricted to modes `0700` and `0600`.
An unknown verb exits 2 with usage on stderr.
Consumers should always pass an explicit model id so their selected encoder never follows a
standalone-default change.

## Environment

| Variable | Effect |
|---|---|
| `JULIE_EMBEDDING_CACHE_DIR` | Model cache root. Defaults to `~/.cache/julie-semantic` (macOS and Linux), `%LOCALAPPDATA%`-rooted on Windows. Shared with Julie by construction. |
| `JULIE_SIDECAR_FORCE_BACKEND=cpu\|metal\|vulkan\|cuda` | CPU skips discovery and benchmarking. Accelerator values probe only that backend, but still resolve to ready CPU when unavailable, failing, tied, or slower. A diagnostic and CI surface — never required for normal operation. |

## Build and test

```
cargo build --release
cargo test
cargo clippy --all-targets -- -D warnings
cargo fmt --check
python3 -B -m unittest discover -s scripts/tests -p 'test_*.py'
```

The toolchain is pinned in `rust-toolchain.toml`.

## Package profiles

Packages use an explicit profile and never bundle model weights:

```text
apple-arm64-metal-portable
apple-x64-metal-portable
linux-x64-vulkan-portable
windows-x64-vulkan-portable
linux-x64-cuda-vendor
windows-x64-cuda-vendor
```

Metal is built into both Apple executables; each uses Metal when the runtime selects it and retains
the CPU backend as the truthful fallback when Metal is unavailable or loses selection. Windows and
Linux profiles place llama.cpp core libraries, CPU modules, and the advertised Vulkan or CUDA module
flat beside the executable. The Apple x64, Linux Vulkan, Windows Vulkan, and CUDA archives remain
package candidates, not physical-hardware support claims, until exact-archive real-device validation
passes on the corresponding hardware.

Build with `scripts/package.sh --profile <name>` or
`scripts/package.ps1 -Profile <name>`. Archive names include sidecar version, Rust target, backend,
and portable/vendor tier. Both scripts reject `-Ctarget-cpu=native`, create and verify the same
`package-manifest.json`, and contain no publication step.

The manifest records every payload file with its SHA-256, size, and role. The manifest itself is
the sole metadata exception because a file cannot truthfully contain its own SHA-256. Verification
rejects every other undeclared file, nested path, model weight, or backend/profile mismatch.
Package builds use a deterministic Cargo-vendored dependency tree. The content-derived native patch
identity recorded in the manifest binds the strict llama.cpp Vulkan reproducibility fixes applied
before shader compilation. Vulkan packaging also parses the generated `diag_f16.spv` and
`tri_f16.spv` modules and rejects any constant-derived half-float store whose source value is not
zero.

## License

MIT — see [LICENSE](LICENSE).
